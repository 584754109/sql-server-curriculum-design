﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;        //引入操作数据库的必要头文件

namespace DrugM
{
    public partial class searchDrug : Form
    {
        public searchDrug()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();                               //关闭此窗体
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string sql = "select * from T_drug where drugName='" + tb_drugName.Text + "'";
            if (!DataOp.login(sql))             //判断药品是否存在
            {
                MessageBox.Show("Drug not found");
                return;
            }


            SqlConnection mycon = new SqlConnection(DataOp.connString);                       //建立链接通路
            try
            {

                mycon.Open();                                                   //打开数据库

                SqlDataAdapter da = new SqlDataAdapter();                       //实例化sqldataadpter
                if (tb_drugName.Text == "")                                     //如果没有输入，则不往下进行
                {
                    MessageBox.Show("Please enter the name of the medicine");
                    return;
                }
                sql = "select * from T_drug where drugName='" + tb_drugName.Text + "'";  //重新赋值，用于执行的sql命令
                SqlCommand cmd1 = new SqlCommand(sql, mycon); //sql语句
                da.SelectCommand = cmd1;                                                            //设置为已实例化SqlDataAdapter的查询命令
                DataSet ds1 = new DataSet();                                                        //实例化dataset
                da.Fill(ds1);                                                                       //把数据填充到ds1


                string result = "";                                              //存储要输出的信息

                //拼接信息
                result += "drugName:\t" + ds1.Tables[0].Rows[0]["drugName"].ToString();
                result += "\r\n\r\n" + "manufacturer:\t" + ds1.Tables[0].Rows[0]["manufacturer"].ToString();
                result += "\r\n\r\n" + "price:\t" + ds1.Tables[0].Rows[0]["price"].ToString();
                result += "\r\n\r\n" + "count:\t" + ds1.Tables[0].Rows[0]["count"].ToString();
                result += "\r\n\r\n" + "type:\t" + ds1.Tables[0].Rows[0]["type"].ToString();
                lb_result.Text = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show("error");                  //发生错误提示信息

            }
            finally
            {
                mycon.Close();                                      //关闭链接通路
            }
                
        }
    }
}
