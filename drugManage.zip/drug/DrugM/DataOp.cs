﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//引用操作数据库必要的头文件
using System.Data;
using System.Data.SqlClient;

namespace DrugM
{
    class DataOp
    {

        //链接数据库的必要信息
        public static string connString = "server=.;database=drugManage;uid=sa;pwd=aa123990;";

        public static bool login(string sql)                //检测是否数据是否存在
        {
            SqlConnection conn = new SqlConnection(connString);            //建立链接通道
            try
            {
                conn.Open();                                               //打开链接通道
                //sql为要执行的sql命令
                
                SqlCommand cmd = new SqlCommand(sql, conn);                //将命令传入通道
                SqlDataReader dr = cmd.ExecuteReader();                    //执行命令
                if (dr.Read())                                             //如果查询到用户
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("error");                                //若发生异常，输出错误信息
            }
            finally
            {
                conn.Close();                                               //关闭链接通道
            }
            return false;
        }


        //执行插删改
        public static bool executeSQL(string sql)
        {
            SqlConnection conn = new SqlConnection(connString);         //建立链接通道
            try
            {
                conn.Open();                                            //打开链接通道
                SqlCommand cmd = new SqlCommand(sql, conn);             //将命令传入通道
                cmd.ExecuteNonQuery();                                  //执行命令
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message);
                MessageBox.Show("error");                       //输出错误信息
                return false;
            }
            finally
            {
                conn.Close();                                             //关闭链接通道

            }
            return true;
        }

        public static bool digital(string str) {
            for (int i = 0; i < str.Length; ++i) {
                if (str[i] > '9' && str[i] < '0')
                    return true;
            }
            return false;
        }

    }
}
