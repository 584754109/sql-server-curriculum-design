﻿namespace DrugM
{
    partial class addDrug
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_type = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.bt_calcel = new System.Windows.Forms.Button();
            this.bt_add = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_count = new System.Windows.Forms.TextBox();
            this.tb_price = new System.Windows.Forms.TextBox();
            this.tb_manufacturer = new System.Windows.Forms.TextBox();
            this.tb_drugName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tb_type
            // 
            this.tb_type.Location = new System.Drawing.Point(177, 217);
            this.tb_type.Name = "tb_type";
            this.tb_type.Size = new System.Drawing.Size(100, 25);
            this.tb_type.TabIndex = 36;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(62, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 15);
            this.label5.TabIndex = 35;
            this.label5.Text = "type:";
            // 
            // bt_calcel
            // 
            this.bt_calcel.Location = new System.Drawing.Point(177, 267);
            this.bt_calcel.Name = "bt_calcel";
            this.bt_calcel.Size = new System.Drawing.Size(78, 23);
            this.bt_calcel.TabIndex = 33;
            this.bt_calcel.Text = "Cancel";
            this.bt_calcel.UseVisualStyleBackColor = true;
            this.bt_calcel.Click += new System.EventHandler(this.bt_calcel_Click);
            // 
            // bt_add
            // 
            this.bt_add.Location = new System.Drawing.Point(62, 267);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(78, 23);
            this.bt_add.TabIndex = 34;
            this.bt_add.Text = "Add";
            this.bt_add.UseVisualStyleBackColor = true;
            this.bt_add.Click += new System.EventHandler(this.bt_add_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(59, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 15);
            this.label4.TabIndex = 29;
            this.label4.Text = "count :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 15);
            this.label3.TabIndex = 30;
            this.label3.Text = "price:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 15);
            this.label2.TabIndex = 31;
            this.label2.Text = "manufacturer:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 32;
            this.label1.Text = "drugName:";
            // 
            // tb_count
            // 
            this.tb_count.Location = new System.Drawing.Point(177, 166);
            this.tb_count.Name = "tb_count";
            this.tb_count.Size = new System.Drawing.Size(100, 25);
            this.tb_count.TabIndex = 25;
            // 
            // tb_price
            // 
            this.tb_price.Location = new System.Drawing.Point(177, 122);
            this.tb_price.Name = "tb_price";
            this.tb_price.Size = new System.Drawing.Size(100, 25);
            this.tb_price.TabIndex = 26;
            // 
            // tb_manufacturer
            // 
            this.tb_manufacturer.Location = new System.Drawing.Point(177, 75);
            this.tb_manufacturer.Name = "tb_manufacturer";
            this.tb_manufacturer.Size = new System.Drawing.Size(100, 25);
            this.tb_manufacturer.TabIndex = 27;
            // 
            // tb_drugName
            // 
            this.tb_drugName.Location = new System.Drawing.Point(177, 31);
            this.tb_drugName.Name = "tb_drugName";
            this.tb_drugName.Size = new System.Drawing.Size(100, 25);
            this.tb_drugName.TabIndex = 28;
            // 
            // addDrug
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 324);
            this.Controls.Add(this.tb_type);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bt_calcel);
            this.Controls.Add(this.bt_add);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_count);
            this.Controls.Add(this.tb_price);
            this.Controls.Add(this.tb_manufacturer);
            this.Controls.Add(this.tb_drugName);
            this.Name = "addDrug";
            this.Text = "addDrug";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_type;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button bt_calcel;
        private System.Windows.Forms.Button bt_add;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_count;
        private System.Windows.Forms.TextBox tb_price;
        private System.Windows.Forms.TextBox tb_manufacturer;
        private System.Windows.Forms.TextBox tb_drugName;
    }
}