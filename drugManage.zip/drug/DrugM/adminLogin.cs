﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrugM
{
    public partial class adminLogin : Form
    {
        public adminLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tb_admin.Text == "" || tb_password.Text == "")
            {
                MessageBox.Show("Please enter the necessary information");
                return;
            }

            string sql = "select * from T_admin where adminName='" + tb_admin.Text + "' and password = '" + tb_password.Text + "'";
            if (DataOp.login(sql))
            {                //如果创建成功，
                MessageBox.Show("land successfully");
                adminManage admin = new adminManage();
                this.Hide();
                admin.ShowDialog();          //模态对话框，防止程序继续往下运行
                this.Show();                 //显示此窗体
            }
            else
                MessageBox.Show("Wrong username or password");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();    //关闭此窗体
        }
    }
}
