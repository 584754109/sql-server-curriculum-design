﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrugM
{
    public partial class userManage : Form
    {
        private int childFormNumber = 0;
        string user;        //存登陆用户名

        public userManage(string user)          //传入用户名的构造函数
        {
            InitializeComponent();
            this.user = user;
        }

        public userManage()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "窗口 " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "文本文件(*.txt)|*.txt|所有文件(*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "文本文件(*.txt)|*.txt|所有文件(*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void addDrugToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addDrug add = new addDrug(user);        //创建addDrug对象窗体
            add.MdiParent = this;                   //设置父窗体
            add.Show();                             //显示窗体
        }

        private void deleteDrugToolStripMenuItem_Click(object sender, EventArgs e)
        {
            deleteDrug delte = new deleteDrug(user);        //创建deleteDrug对象窗体
            delte.MdiParent = this;                   //设置父窗体
            delte.Show();                             //显示窗体

        }

        private void uodateDrugToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updateDrug update = new updateDrug(user);        //创建updateDrug对象窗体
            update.MdiParent = this;                   //设置父窗体
            update.Show();                             //显示窗体

        }

        private void searchDrugToolStripMenuItem_Click(object sender, EventArgs e)
        {
            searchDrug search = new searchDrug();        //创建searchDrug对象窗体
            search.MdiParent = this;                   //设置父窗体
            search.Show();                             //显示窗体
        }

        private void allDrugToolStripMenuItem_Click(object sender, EventArgs e)
        {
            allDrug all = new allDrug();        //创建allDrug对象窗体
            all.MdiParent = this;                   //设置父窗体
            all.Show();                             //显示窗体

        }

        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
