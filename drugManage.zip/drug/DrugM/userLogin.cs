﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrugM
{
    public partial class userLogin : Form
    {
        public userLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (tb_userName.Text == "" || tb_password.Text == "")       //检测用户名和密码是否输入
            {
                MessageBox.Show("Please enter full information");
                return;
            }
            
            string sql = "select * from T_user where userName='" + tb_userName.Text + "'	and password='" + tb_password.Text + "'";
            if (DataOp.login(sql))
            {                //如果创建成功，
                MessageBox.Show("land successfully ");
                userManage user = new userManage(tb_userName.Text);
                this.Hide();
                user.ShowDialog();          //模态对话框，防止程序继续往下运行
                this.Show();                //显示登陆窗体
            }
            else
                MessageBox.Show("Wrong username or password");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            register re = new register();   //创建注册窗体
            this.Hide();                    //隐藏此窗体
            re.ShowDialog();                //显示模态对话框，阻止程序继续进行
            this.Show();                    //进行此处，显示此窗体
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminLogin admin = new adminLogin();    //创建管理员登陆窗体
            this.Hide();                            //隐藏此窗体
            admin.ShowDialog();                     //显示模态对话框，阻止程序继续运行
            Application.Exit();                     //程序退出
        }
    }
}
