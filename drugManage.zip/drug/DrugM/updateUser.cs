﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrugM
{
    public partial class updateUser : Form
    {
        public updateUser()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (DataOp.digital(tb_tel.Text) || tb_tel.Text.Length != 11)      //判断电话号码是否合法
            {
                MessageBox.Show("Please enter a valid telephone number");
                return;
            }
            if (DataOp.digital(tb_age.Text))
            {         //判断年龄是否合法
                MessageBox.Show("Please enter a valid age");
                return;
            }

            string sql = "select * from T_user where userName = '"+tb_userName.Text+"'";            //用于检测用户是否存在
            if (DataOp.login(sql))
            {
                //判断最终需要修改信息
                sql = "";
                if (tb_tel.Text != "") sql += "tel='" + tb_tel.Text + "',";
                if (tb_gender.Text != "") sql += "gender='" + tb_gender.Text + "',";
                if (tb_age.Text != "") sql += "age=" + tb_age.Text + ",";
                if (tb_password.Text != "") sql += "password='" + tb_password.Text + "',";

                if (sql == "")                                             //若空则不存在要删除命令
                    MessageBox.Show("Please fill in valid information");
                else
                    sql = "update T_user set " + sql.Substring(0, sql.Length - 1) + " where userName='" + tb_userName.Text + "'";

                if (!DataOp.executeSQL(sql))
                    return;                                    //执行命令
                MessageBox.Show("modify successfully ");
            }else 
            {
                MessageBox.Show("The user does not exist. ");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();           //关闭此窗体
        }
    }
}
