﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;            //引入操作数据库的必要文件

namespace DrugM
{
    public partial class history : Form
    {
        public history()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //sql为要执行的命令
            string sql = "delete T_history";
            if (!DataOp.executeSQL(sql))    //若未成功执行命令，跳出事件
                return;
            MessageBox.Show("Empty the success");    //若执行则表示成功运行
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();           //关闭此窗体
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //sql存储登陆数据库的信息

            SqlConnection mycon = new SqlConnection(DataOp.connString);                        //建立链接通道
            try
            {

                mycon.Open();                                                    //打开链接通道        

                SqlDataAdapter da = new SqlDataAdapter();                        //实例化sqldataadpter

                string sql = "select * from T_history";                         //用于置行的sql命令

                SqlCommand cmd = new SqlCommand(sql, mycon);                     //创建执行sql命令的对象
                SqlDataReader read = cmd.ExecuteReader();                        //创建数据读取器
                BindingSource s = new BindingSource();                           //用于读取接收数据资源
                s.DataSource = read;
                dgv_result.DataSource = s;                                        //将读取资源赋值给dataGridView，显示数据

            }
            catch (Exception ex)
            {
                //throw new Exception();
                MessageBox.Show("error");                                      //出现错误。

            }
            finally
            {
                mycon.Close();                                                     //关闭链接通道
            }
        }

    }
}
