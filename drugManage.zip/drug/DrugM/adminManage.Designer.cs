﻿namespace DrugM
{
    partial class adminManage
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.userToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.returnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userToolStripMenuItem,
            this.drugToolStripMenuItem,
            this.historyToolStripMenuItem,
            this.returnToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(843, 27);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // userToolStripMenuItem
            // 
            this.userToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addUserToolStripMenuItem,
            this.deleteUserToolStripMenuItem,
            this.updateUserToolStripMenuItem,
            this.searchUserToolStripMenuItem,
            this.allUserToolStripMenuItem});
            this.userToolStripMenuItem.Name = "userToolStripMenuItem";
            this.userToolStripMenuItem.Size = new System.Drawing.Size(53, 23);
            this.userToolStripMenuItem.Text = "user";
            // 
            // addUserToolStripMenuItem
            // 
            this.addUserToolStripMenuItem.Name = "addUserToolStripMenuItem";
            this.addUserToolStripMenuItem.Size = new System.Drawing.Size(166, 24);
            this.addUserToolStripMenuItem.Text = "addUser";
            this.addUserToolStripMenuItem.Click += new System.EventHandler(this.addUserToolStripMenuItem_Click);
            // 
            // deleteUserToolStripMenuItem
            // 
            this.deleteUserToolStripMenuItem.Name = "deleteUserToolStripMenuItem";
            this.deleteUserToolStripMenuItem.Size = new System.Drawing.Size(166, 24);
            this.deleteUserToolStripMenuItem.Text = "deleteUser";
            this.deleteUserToolStripMenuItem.Click += new System.EventHandler(this.deleteUserToolStripMenuItem_Click);
            // 
            // updateUserToolStripMenuItem
            // 
            this.updateUserToolStripMenuItem.Name = "updateUserToolStripMenuItem";
            this.updateUserToolStripMenuItem.Size = new System.Drawing.Size(166, 24);
            this.updateUserToolStripMenuItem.Text = "updateUser";
            this.updateUserToolStripMenuItem.Click += new System.EventHandler(this.updateUserToolStripMenuItem_Click);
            // 
            // searchUserToolStripMenuItem
            // 
            this.searchUserToolStripMenuItem.Name = "searchUserToolStripMenuItem";
            this.searchUserToolStripMenuItem.Size = new System.Drawing.Size(166, 24);
            this.searchUserToolStripMenuItem.Text = "searchUser";
            this.searchUserToolStripMenuItem.Click += new System.EventHandler(this.searchUserToolStripMenuItem_Click);
            // 
            // allUserToolStripMenuItem
            // 
            this.allUserToolStripMenuItem.Name = "allUserToolStripMenuItem";
            this.allUserToolStripMenuItem.Size = new System.Drawing.Size(166, 24);
            this.allUserToolStripMenuItem.Text = "allUser";
            this.allUserToolStripMenuItem.Click += new System.EventHandler(this.allUserToolStripMenuItem_Click);
            // 
            // drugToolStripMenuItem
            // 
            this.drugToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addDrugToolStripMenuItem,
            this.deleteDrugToolStripMenuItem,
            this.updateDrugToolStripMenuItem,
            this.searchDrugToolStripMenuItem,
            this.allDrugToolStripMenuItem});
            this.drugToolStripMenuItem.Name = "drugToolStripMenuItem";
            this.drugToolStripMenuItem.Size = new System.Drawing.Size(57, 23);
            this.drugToolStripMenuItem.Text = "drug";
            // 
            // addDrugToolStripMenuItem
            // 
            this.addDrugToolStripMenuItem.Name = "addDrugToolStripMenuItem";
            this.addDrugToolStripMenuItem.Size = new System.Drawing.Size(170, 24);
            this.addDrugToolStripMenuItem.Text = "addDrug";
            this.addDrugToolStripMenuItem.Click += new System.EventHandler(this.addDrugToolStripMenuItem_Click);
            // 
            // deleteDrugToolStripMenuItem
            // 
            this.deleteDrugToolStripMenuItem.Name = "deleteDrugToolStripMenuItem";
            this.deleteDrugToolStripMenuItem.Size = new System.Drawing.Size(170, 24);
            this.deleteDrugToolStripMenuItem.Text = "deleteDrug";
            this.deleteDrugToolStripMenuItem.Click += new System.EventHandler(this.deleteDrugToolStripMenuItem_Click);
            // 
            // updateDrugToolStripMenuItem
            // 
            this.updateDrugToolStripMenuItem.Name = "updateDrugToolStripMenuItem";
            this.updateDrugToolStripMenuItem.Size = new System.Drawing.Size(170, 24);
            this.updateDrugToolStripMenuItem.Text = "updateDrug";
            this.updateDrugToolStripMenuItem.Click += new System.EventHandler(this.updateDrugToolStripMenuItem_Click);
            // 
            // searchDrugToolStripMenuItem
            // 
            this.searchDrugToolStripMenuItem.Name = "searchDrugToolStripMenuItem";
            this.searchDrugToolStripMenuItem.Size = new System.Drawing.Size(170, 24);
            this.searchDrugToolStripMenuItem.Text = "searchDrug";
            this.searchDrugToolStripMenuItem.Click += new System.EventHandler(this.searchDrugToolStripMenuItem_Click);
            // 
            // allDrugToolStripMenuItem
            // 
            this.allDrugToolStripMenuItem.Name = "allDrugToolStripMenuItem";
            this.allDrugToolStripMenuItem.Size = new System.Drawing.Size(170, 24);
            this.allDrugToolStripMenuItem.Text = "allDrug";
            this.allDrugToolStripMenuItem.Click += new System.EventHandler(this.allDrugToolStripMenuItem_Click);
            // 
            // historyToolStripMenuItem
            // 
            this.historyToolStripMenuItem.Name = "historyToolStripMenuItem";
            this.historyToolStripMenuItem.Size = new System.Drawing.Size(73, 23);
            this.historyToolStripMenuItem.Text = "history";
            this.historyToolStripMenuItem.Click += new System.EventHandler(this.historyToolStripMenuItem_Click);
            // 
            // returnToolStripMenuItem
            // 
            this.returnToolStripMenuItem.Name = "returnToolStripMenuItem";
            this.returnToolStripMenuItem.Size = new System.Drawing.Size(68, 23);
            this.returnToolStripMenuItem.Text = "return";
            this.returnToolStripMenuItem.Click += new System.EventHandler(this.returnToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 499);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip.Size = new System.Drawing.Size(843, 24);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 19);
            this.toolStripStatusLabel.Text = "状态";
            // 
            // adminManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 523);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "adminManage";
            this.Text = "adminManage";
            this.Load += new System.EventHandler(this.adminManage_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem userToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem drugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem returnToolStripMenuItem;
    }
}



