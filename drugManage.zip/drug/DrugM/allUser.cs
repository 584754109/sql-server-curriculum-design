﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;        //用于操作数据库的头文件

namespace DrugM
{
    public partial class allUser : Form
    {
        private void dgv_result_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public allUser()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //str为存储登陆数据库的信息

            SqlConnection mycon = new SqlConnection(DataOp.connString);                       //建立链接通路
            try
            {

                mycon.Open();                                                   //打开链接通道

                SqlDataAdapter da = new SqlDataAdapter();                       //实例化sqldataadpter

                string sql = "select * from T_user";                             //用于置行的sql命令

                SqlCommand cmd = new SqlCommand(sql, mycon);                    //创建执行sql命令对象
                SqlDataReader read = cmd.ExecuteReader();                       //数据读取器
                BindingSource s = new BindingSource();                          //用于接收数据
                s.DataSource = read;                                            //接收数据
                dgv_result.DataSource = s;                                      //将数据赋值给前端界面

            }
            catch (Exception ex)
            {
                //throw new Exception();
                MessageBox.Show("error");                                    //异常报错

            }
            finally
            {
                mycon.Close();                                                  //关闭链接通道
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
