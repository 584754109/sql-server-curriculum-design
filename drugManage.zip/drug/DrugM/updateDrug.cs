﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrugM
{
    public partial class updateDrug : Form
    {
        string user;
        public updateDrug()
        {
            InitializeComponent();
        }
        public updateDrug(string user)   //创建接收用户名的构造函数
        {
            InitializeComponent();
            this.user = user;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();                   //关闭此窗体
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select * from T_drug where drugName='" + tb_drugName.Text + "'";
            if (!DataOp.login(sql))              //判断是否存在此药品
            {
                MessageBox.Show("Drugs don't exist");    
                return;
            }
            //判断最终需要修改信息
            sql = "";           //重置sql命令
            if (tb_drugName.Text != "") sql += "drugName='" + tb_drugName.Text + "',";
            if (tb_manufacturer.Text != "") sql += "manufacturer='" + tb_manufacturer.Text + "',";
            if (tb_price.Text != "") sql += "price=" + tb_price.Text + ",";
            if (tb_count.Text != "") sql += "[count]=" + tb_count.Text + ",";
            if (tb_type.Text != "") sql += "[type]='" + tb_type.Text + "',";

            if (sql == "")                                             //若空则不存在要删除命令
                MessageBox.Show("Please fill in valid information");

            else
                sql = "update T_drug set " + sql + "operator='" + user + "' where drugName='" + tb_drugName.Text + "'";

            if (!DataOp.executeSQL(sql))
                return;                                    //执行命令,若不成功则输出错误信息并return
            MessageBox.Show("modify successfully ");
        }


    }
}
