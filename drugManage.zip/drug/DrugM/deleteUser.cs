﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrugM
{
    public partial class deleteUser : Form
    {
        public deleteUser()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();       //关闭此窗体
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select * from T_user where userName='" + tb_userName.Text + "'";
            if (DataOp.login(sql))              //判断是否用户存在
            {

                sql = "delete T_user where userName='" + tb_userName.Text + "'";        //执行删除指定用户
                if (!DataOp.executeSQL(sql))    //若未成功执行命令，跳出事件
                    return;
                MessageBox.Show("successfully delete ");    //若执行则表示成功运行

            }
            else
            {                                           //若执行这里。则代表用户不存在
                MessageBox.Show("The user does not exist. ");
            }
        }
    }
}
