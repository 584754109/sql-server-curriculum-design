﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrugM
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();           //关闭窗体
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tb_age.Text == "" || tb_gender.Text == "" || tb_password.Text == "" || tb_tel.Text == "" || tb_userName.Text == ""){     //判断是否有缺少信息
                MessageBox.Show("Please enter full information");
                return ;
            }
            if (DataOp.digital(tb_tel.Text) || tb_tel.Text.Length != 11)      //判断电话号码是否合法
            {
                MessageBox.Show("Please enter a valid telephone number");
                return;
            }
            if (DataOp.digital(tb_age.Text))
            {         //判断年龄是否合法
                MessageBox.Show("Please enter a valid age");
                return;
            }
            string sql = "select * from T_user where userName='"+tb_userName.Text+"'";
            if (DataOp.login(sql))              //检测用户是否存在
            {
                MessageBox.Show("User already exists");
                return;
            }
            sql = "insert T_user(userName,[password],gender,tel,age) values('" + tb_userName.Text + "','" + tb_password.Text + "','" + tb_gender.Text + "','" + tb_tel.Text + "'," + tb_age.Text + ")";
            if (!DataOp.executeSQL(sql))    //若未成功执行命令，跳出事件
                return;
            MessageBox.Show("successfully added ");    //若执行则表示成功运行
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void tb_age_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_tel_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_gender_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_password_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_userName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
