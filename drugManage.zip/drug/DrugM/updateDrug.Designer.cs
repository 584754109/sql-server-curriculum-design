﻿namespace DrugM
{
    partial class updateDrug
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.tb_count = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_price = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_manufacturer = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_drugName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_type = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(201, 288);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 13;
            this.button2.Text = "cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tb_count
            // 
            this.tb_count.Location = new System.Drawing.Point(186, 189);
            this.tb_count.Name = "tb_count";
            this.tb_count.Size = new System.Drawing.Size(128, 25);
            this.tb_count.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "count:";
            // 
            // tb_price
            // 
            this.tb_price.Location = new System.Drawing.Point(186, 144);
            this.tb_price.Name = "tb_price";
            this.tb_price.Size = new System.Drawing.Size(128, 25);
            this.tb_price.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(63, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "price:";
            // 
            // tb_manufacturer
            // 
            this.tb_manufacturer.Location = new System.Drawing.Point(186, 100);
            this.tb_manufacturer.Name = "tb_manufacturer";
            this.tb_manufacturer.Size = new System.Drawing.Size(128, 25);
            this.tb_manufacturer.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "manufacturer:";
            // 
            // tb_drugName
            // 
            this.tb_drugName.Location = new System.Drawing.Point(186, 49);
            this.tb_drugName.Name = "tb_drugName";
            this.tb_drugName.Size = new System.Drawing.Size(128, 25);
            this.tb_drugName.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(63, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "drugName:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(82, 288);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "update";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 235);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "type:";
            // 
            // tb_type
            // 
            this.tb_type.Location = new System.Drawing.Point(186, 232);
            this.tb_type.Name = "tb_type";
            this.tb_type.Size = new System.Drawing.Size(128, 25);
            this.tb_type.TabIndex = 9;
            // 
            // updateDrug
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(428, 374);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tb_type);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_count);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_price);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_manufacturer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_drugName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "updateDrug";
            this.Text = "updateDrug";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tb_count;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_price;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_manufacturer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_drugName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_type;
    }
}