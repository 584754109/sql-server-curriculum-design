﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrugM
{
    public partial class deleteDrug : Form
    {
        string user;
        public deleteDrug()
        {
            InitializeComponent();
        }

        public deleteDrug(string user)      //创建接收用户名的构造函数
        {
            InitializeComponent();
            this.user = user;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select * from T_drug where drugName='" + tb_drugName.Text + "'";
            if (DataOp.login(sql))              //判断是否存在此药品
            {
                //此时sql为放入历史数据里的命令
                sql = "insert T_history(operator,drugName,operate,[time]) values('"+user+"','"+tb_drugName.Text+"','delete',CONVERT(varchar,GETDATE(),120))";
                if (!DataOp.executeSQL(sql))    //若未成功执行命令，跳出事件
                        return;
                
                sql = "delete T_drug where drugName='" + tb_drugName.Text + "'";        //执行删除指定药品
                if (!DataOp.executeSQL(sql))    //若未成功执行命令，跳出事件
                    return;
                MessageBox.Show("successfully delete ");    //若执行则表示成功运行

            }
            else
            {                                           //若执行这里。则代表药品不存在
                MessageBox.Show("Drugs don't exist");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();           //退出此应用
        }
    }
}
