﻿namespace DrugM
{
    partial class userManage
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.addDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uodateDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allDrugToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.returnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addDrugToolStripMenuItem,
            this.deleteDrugToolStripMenuItem,
            this.uodateDrugToolStripMenuItem,
            this.searchDrugToolStripMenuItem,
            this.allDrugToolStripMenuItem,
            this.returnToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(843, 27);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // addDrugToolStripMenuItem
            // 
            this.addDrugToolStripMenuItem.Name = "addDrugToolStripMenuItem";
            this.addDrugToolStripMenuItem.Size = new System.Drawing.Size(88, 23);
            this.addDrugToolStripMenuItem.Text = "addDrug";
            this.addDrugToolStripMenuItem.Click += new System.EventHandler(this.addDrugToolStripMenuItem_Click);
            // 
            // deleteDrugToolStripMenuItem
            // 
            this.deleteDrugToolStripMenuItem.Name = "deleteDrugToolStripMenuItem";
            this.deleteDrugToolStripMenuItem.Size = new System.Drawing.Size(106, 23);
            this.deleteDrugToolStripMenuItem.Text = "deleteDrug";
            this.deleteDrugToolStripMenuItem.Click += new System.EventHandler(this.deleteDrugToolStripMenuItem_Click);
            // 
            // uodateDrugToolStripMenuItem
            // 
            this.uodateDrugToolStripMenuItem.Name = "uodateDrugToolStripMenuItem";
            this.uodateDrugToolStripMenuItem.Size = new System.Drawing.Size(113, 23);
            this.uodateDrugToolStripMenuItem.Text = "updateDrug";
            this.uodateDrugToolStripMenuItem.Click += new System.EventHandler(this.uodateDrugToolStripMenuItem_Click);
            // 
            // searchDrugToolStripMenuItem
            // 
            this.searchDrugToolStripMenuItem.Name = "searchDrugToolStripMenuItem";
            this.searchDrugToolStripMenuItem.Size = new System.Drawing.Size(108, 23);
            this.searchDrugToolStripMenuItem.Text = "searchDrug";
            this.searchDrugToolStripMenuItem.Click += new System.EventHandler(this.searchDrugToolStripMenuItem_Click);
            // 
            // allDrugToolStripMenuItem
            // 
            this.allDrugToolStripMenuItem.Name = "allDrugToolStripMenuItem";
            this.allDrugToolStripMenuItem.Size = new System.Drawing.Size(76, 23);
            this.allDrugToolStripMenuItem.Text = "allDrug";
            this.allDrugToolStripMenuItem.Click += new System.EventHandler(this.allDrugToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 499);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip.Size = new System.Drawing.Size(843, 24);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 19);
            this.toolStripStatusLabel.Text = "状态";
            // 
            // returnToolStripMenuItem
            // 
            this.returnToolStripMenuItem.Name = "returnToolStripMenuItem";
            this.returnToolStripMenuItem.Size = new System.Drawing.Size(68, 23);
            this.returnToolStripMenuItem.Text = "return";
            this.returnToolStripMenuItem.Click += new System.EventHandler(this.returnToolStripMenuItem_Click);
            // 
            // userManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 523);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "userManage";
            this.Text = "userManage";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem addDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uodateDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allDrugToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem returnToolStripMenuItem;
    }
}



