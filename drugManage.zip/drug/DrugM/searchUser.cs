﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;            //引入必要的头文件

namespace DrugM
{
    public partial class searchUser : Form
    {
        public searchUser()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tb_name.Text == "")                                         //若没有用户名，返回重新输入
            {
                MessageBox.Show("Please enter user name");
                return;
            }
            string sql = "select * from T_user where userName = '"+tb_name.Text+"'";
            if(!DataOp.login(sql))
            {
                MessageBox.Show("The username does not exist");
                return ;
            }

            SqlConnection mycon = new SqlConnection(DataOp.connString);                        //建立链接通道
            try {                
                mycon.Open();                                                   //打开链接通道 

                SqlDataAdapter da = new SqlDataAdapter();                       //实例化sqldataadpter

                sql = "select * from T_user where userName='" + tb_name.Text + "'";   //用于执行的sql命令
                SqlCommand cmd1 = new SqlCommand(sql, mycon); //sql语句
                da.SelectCommand = cmd1;                                        //设置为已实例化SqlDataAdapter的查询命令
                DataSet ds1 = new DataSet();                                    //实例化dataset
                da.Fill(ds1);                                                   //把数据填充到ds1
                
                //result为输出的个人信息
                string result = "";

                result += "userName:\t" + ds1.Tables[0].Rows[0]["userName"].ToString();
                result += "\r\n\r\n" + "gender:\t" + ds1.Tables[0].Rows[0]["gender"].ToString();
                result += "\r\n\r\n" + "telephone:\t" + ds1.Tables[0].Rows[0]["tel"].ToString();
                result += "\r\n\r\n" + "age:\t" + ds1.Tables[0].Rows[0]["age"].ToString();
                lb_result.Text = result;
                }
                catch (Exception ex)
                {
                    //throw new Exception();
                    MessageBox.Show("error");                                 //发生错误

                }
                finally
                {
                    mycon.Close();                                                      //关闭通道
                }
        }
    }
}
