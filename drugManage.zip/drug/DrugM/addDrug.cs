﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrugM
{
    public partial class addDrug : Form
    {
        string user;

        public addDrug(string user)          //创建接收用户名的构造函数
        {
            InitializeComponent();
            this.user = user;
        }

        public addDrug()
        {
            InitializeComponent();
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            string sql = "select * from T_drug where drugName='" + tb_drugName.Text + "'";
            if (DataOp.login(sql))             //判断药品是否存在
            {
                MessageBox.Show("Drugs already exist");
                return;
            }
            //sql为要执行的命令
            sql = "insert into T_drug (drugName,manufacturer,price,[count],[type],operator) values ('" + tb_drugName.Text + "','" + tb_manufacturer.Text + "'," + tb_price.Text + "," + tb_count.Text + ",'" + tb_type.Text + "','" + user + "')";
            if (!DataOp.executeSQL(sql))    //若未成功执行命令，跳出事件
                return;
            MessageBox.Show("successfully added ");    //若执行则表示成功运行
        }

        private void bt_calcel_Click(object sender, EventArgs e)
        {
            this.Close();       //关闭此窗体
        }
    }
}
